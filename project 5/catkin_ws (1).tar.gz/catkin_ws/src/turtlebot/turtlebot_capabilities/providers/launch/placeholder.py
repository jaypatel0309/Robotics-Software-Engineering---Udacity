#!/usr/bin/env python

from time import sleep

while True:
    sleep(0.1)
